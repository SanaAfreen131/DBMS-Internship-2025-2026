import { env } from "./env";
import { ChatSession } from "./models/ChatSession";

export type Role = "user" | "assistant";

function ttlDate(from = new Date()) {
  return new Date(from.getTime() + env.SESSION_TTL_HOURS * 60 * 60 * 1000);
}

export class Repo {
  async createSession(sessionId: string, userId: string) {
    await ChatSession.create({
      sessionId,
      userId,
      messages: [],
      createdAt: new Date(),
      expiresAt: ttlDate(),
    });
  }

async touchSession(sessionId: string, userId?: string) {
  await ChatSession.updateOne(
    { sessionId },
    {
      $set: { expiresAt: ttlDate() },
      ...(userId
        ? { $setOnInsert: { sessionId, userId, createdAt: new Date() } }
        : {}),
    },
    { upsert: Boolean(userId) }
  );
}


  /**
   * Append a message and keep only the last N messages (privacy minimization).
   * Stores ONLY what you pass in (you can pass anonymized text only from services).
   */
  async appendMessage(msg: {
    sessionId: string;
    userId: string;
    role: Role;
    contentOriginal?: string;
    contentAnonymized?: string;
    entities?: Array<{ type: string; value: string }>;
    route: "local" | "external";
    routeReason: string;
    keepLast?: number; // optional override (default 12)
  }) {
    const keepLast = typeof msg.keepLast === "number" ? msg.keepLast : 12;

await ChatSession.updateOne(
  { sessionId: msg.sessionId },
  {
    $setOnInsert: {
      sessionId: msg.sessionId,
      userId: msg.userId,
      createdAt: new Date(),
      // IMPORTANT: do NOT include `messages` here
    },
    $push: {
      messages: {
        $each: [
          {
            from: msg.role,
            text: msg.contentOriginal ?? "",
            textAnonymized: msg.contentAnonymized ?? "",
            entities: msg.entities ?? [],
            route: msg.route,
            routeReason: msg.routeReason,
            timestamp: new Date(),
          },
        ],
        $slice: -keepLast,
      },
    },
    $set: { expiresAt: ttlDate() },
  },
  { upsert: true }
);
  }

  /**
   * Get last N messages only (already minimized in DB, but slicing here is fine too).
   * Returns the shape that services.ts can consume.
   */
  async getRecentMessages(sessionId: string, limit: number) {
    const session = await ChatSession.findOne(
      { sessionId },
      { messages: { $slice: -limit } }
    ).lean();

    const messages = (session as any)?.messages ?? [];
    return messages.map((m: any) => ({
      role: m.from as Role,
      contentOriginal: m.text as string,
      contentAnonymized: m.textAnonymized as string,
      createdAt: m.timestamp as Date,
      route: m.route as "local" | "external",
      routeReason: m.routeReason as string,
    }));
  }

  async deleteSessionAndData(sessionId: string) {
    await ChatSession.deleteOne({ sessionId });
  }
}
