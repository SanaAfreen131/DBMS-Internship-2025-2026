import dotenv from "dotenv";
import { z } from "zod";
dotenv.config();

function must(name: string): string {
  const v = process.env[name];
  if (!v) throw new Error(`Missing env var: ${name}`);
  return v;
}

export const env = {
  PORT: Number(process.env.PORT ?? 3000),

  // Mongo not used yet, but required by spec
  MONGO_URI: must("MONGO_URI").trim(),

  OLLAMA_URL: process.env.OLLAMA_URL ?? "http://localhost:11434",
  OLLAMA_MODEL: process.env.OLLAMA_MODEL ?? "llama3.1:8b",

  OPENAI_API_KEY: process.env.OPENAI_API_KEY ?? "",
  OPENAI_MODEL: process.env.OPENAI_MODEL ?? "gpt-4o-mini",

  SESSION_TTL_HOURS: Number(process.env.SESSION_TTL_HOURS ?? 2),
};
