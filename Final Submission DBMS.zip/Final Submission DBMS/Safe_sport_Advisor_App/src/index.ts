import express from "express";
import cors from "cors";
import helmet from "helmet";
import { z } from "zod";
import path from "node:path";
import { env } from "./env";
import { Services } from "./services";
import { connectDb } from "./db";

const app = express();
const svc = new Services();

app.use(
  helmet({
    contentSecurityPolicy: {
      useDefaults: true,
      directives: {
        "script-src": ["'self'", "'unsafe-inline'", "https://cdn.jsdelivr.net"],
        "style-src": ["'self'", "'unsafe-inline'", "https://cdnjs.cloudflare.com"],
        "font-src": ["'self'", "https://cdnjs.cloudflare.com", "data:"],
      },
    },
  })
);

// keep CORS permissive for demo; if you want, set CORS_ORIGIN in .env
const corsOrigin = process.env.CORS_ORIGIN;
app.use(corsOrigin ? cors({ origin: corsOrigin, credentials: true }) : cors());

app.use(express.json());

// Optional: serve a frontend if you put it into ./public
app.use(express.static(path.join(process.cwd(), "public")));

app.get("/health", (_, res) => res.json({ ok: true }));

/**
 *  App 1 compatibility endpoint
 * Frontend can call: POST /chat { message, userId?, sessionId?, close? }
 * Returns: { reply, routed_to, anonymized, redactions, sessionId, createdNewSession, ... }
 */
app.post("/chat", async (req, res) => {
  try {
    const schema = z.object({
      message: z.string().min(1),
      userId: z.string().min(1).optional(),
      sessionId: z.string().min(1).optional(),
      close: z.boolean().optional(),
    });

    const parsed = schema.safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ error: "bad_request" });

    const userId = parsed.data.userId ?? "demo-user";
    let sessionId = parsed.data.sessionId;

    // close session (optional)
    if (parsed.data.close === true) {
      if (!sessionId) return res.status(400).json({ error: "sessionId_required" });
      await svc.closeSession(sessionId);
      return res.json({ ok: true, closed: true, sessionId });
    }

    // create session if none provided
    let createdNewSession = false;
    if (!sessionId) {
      sessionId = await svc.createSession(userId);
      createdNewSession = true;
    }

    const out = await svc.handleMessage({
      sessionId,
      userId,
      message: parsed.data.message,
    });

    // App 2 returns: { response, usedModel, redactions }
    const replyText = (out as any).response ?? "";
    const redactions = (out as any).redactions ?? [];
    const usedModel = (out as any).usedModel ?? "local";

    return res.json({
      // App 1-style keys:
      reply: replyText,
      routed_to: usedModel,
      anonymized: Array.isArray(redactions) && redactions.length > 0,

      // App 2-style keys (also included):
      response: replyText,
      usedModel,
      redactions,

      // session handling:
      sessionId,
      createdNewSession,
    });
  } catch (err: any) {
    console.error("[/chat] error:", err);
    return res.status(500).json({ error: "internal_error", detail: err?.message });
  }
});

app.post("/v1/sessions", async (req, res) => {
  try {
    const schema = z.object({ userId: z.string().min(1) });
    const parsed = schema.safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ error: "bad_request" });

    const sessionId = await svc.createSession(parsed.data.userId);
    return res.status(201).json({ sessionId });
  } catch (err: any) {
    console.error("[/v1/sessions] error:", err);
    return res.status(500).json({ error: "internal_error" });
  }
});

app.post("/v1/chat/messages", async (req, res) => {
  try {
    console.log("CHAT_MESSAGES_HANDLER_VERSION = 2026-01-30-A", req.body);

    const schema = z.object({
      sessionId: z.string().min(1),
      userId: z.string().min(1),
      message: z.string().optional(),

      // accept 0/1 as number or string; default to 0 (keep open)
      closeFlag: z
        .union([z.literal(0), z.literal(1), z.literal("0"), z.literal("1")])
        .optional(),
    });

    const parsed = schema.safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ error: "bad_request" });

    const { sessionId, userId } = parsed.data;

    // default: keep session open
    const closeFlagNum =
      parsed.data.closeFlag === undefined ? 0 : Number(parsed.data.closeFlag);

    // close ONLY when explicitly requested
    if (closeFlagNum === 1) {
      await svc.closeSession(sessionId);
      return res.json({ ok: true, closed: true, sessionId });
    }

    const message = parsed.data.message;
    if (!message || message.trim().length === 0) {
      return res.status(400).json({ error: "message_required" });
    }

    const out = await svc.handleMessage({ sessionId, userId, message });
    return res.json({ ...out, ok: true, closed: false, sessionId });
  } catch (err: any) {
    console.error("[/v1/chat/messages] error:", err);
    return res.status(500).json({ error: "internal_error", detail: err?.message });
  }
});

// connect DB BEFORE listening
(async () => {
  try {
    await connectDb();
    app.listen(env.PORT, () => {
      console.log(`🚀 API running on http://localhost:${env.PORT}`);
    });
  } catch (err) {
    console.error("[startup] failed:", err);
    process.exit(1);
  }
})();
