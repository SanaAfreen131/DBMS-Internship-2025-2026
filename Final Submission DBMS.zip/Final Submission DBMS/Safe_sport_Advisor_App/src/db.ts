import mongoose from "mongoose";
import { env } from "./env";

export async function connectDb() {
  if (!env.MONGO_URI) {
    console.warn("[db] MONGO_URI not set — DB disabled");
    return;
  }

  await mongoose.connect(env.MONGO_URI);
  console.log("[db] connected");
  console.log("[db] connected to", mongoose.connection.name);
  mongoose.connection.on("error", (err) => {
    console.error("[db] connection error", err);
  });
}
