import OpenAI from "openai";
import { env } from "./env";

export type DetectionResult = {
  isSensitive: boolean;
  entities: Array<{ type: string; value: string }>;
};

export class OllamaLLM {
  /**
   * 1) Sensitivity detection (JSON-only, used for routing decisions)
   */
  async detectSensitive(text: string): Promise<DetectionResult> {
    const prompt = `
Return ONLY valid JSON. No markdown, no comments.

Schema:
{
  "isSensitive": boolean,
  "entities": [{"type": "EMAIL|PHONE|DATE|LOCATION|ID|NAME|AGE|MEDICAL|OTHER", "value": "string"}]
}

Rules:
- Mark isSensitive=true if ANY personal identifier is present (EMAIL, PHONE, NAME, LOCATION, ID, exact DATE of birth)
  OR if the text describes urgent medical red flags (e.g., chest pain, signs of heart attack, trouble breathing, fainting, severe bleeding).
- If unsure, set isSensitive=true.
- "entities" should include the exact substrings from the text.

Text: ${JSON.stringify(text)}
`.trim();

    const r = await fetch(`${env.OLLAMA_URL}/api/generate`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        model: env.OLLAMA_MODEL,
        prompt,
        stream: false,
        format: "json",
        options: { temperature: 0 },
      }),
    });

    if (!r.ok) throw new Error(`Ollama error ${r.status}`);
    const data: any = await r.json();

    let parsed: any;
    try {
      parsed = JSON.parse(data.response);
    } catch {
      return {
        isSensitive: true,
        entities: [{ type: "OTHER", value: "invalid_json_from_model" }],
      };
    }

    return {
      isSensitive: Boolean(parsed.isSensitive),
      entities: Array.isArray(parsed.entities) ? parsed.entities : [],
    };
  }

  /**
   * 2) Second-pass redaction helper (BPMN-style tagging)
   * Returns text with <REDACT type="...">...</REDACT> markers.
   * services.ts will validate & apply them deterministically.
   */
  async proposeRedactions(text: string): Promise<string> {
    const prompt = [
       "You are a privacy redaction helper.",
    "",
    "Your task is to IDENTIFY and MARK personal data that appears verbatim in the input text.",
    "",
    'Wrap ONLY the smallest exact spans that should be redacted with tags exactly like:',
    '<REDACT type="EMAIL|PHONE|NAME|LOCATION|DATE|ID|AGE">...</REDACT>',
    "",
    "Definitions (important):",
    "- NAME: a real or plausible person name (first name, last name, or both),",
    "  even if it is lowercase, uncommon, or not capitalized.",
    "  Example: 'helga ottenmaierklaus', 'john', 'anna-marie'.",
    "- LOCATION: a city, region, or country.",
    "- AGE: an explicit age number referring to a person.",
    "",
    "Rules (very important):",
    "- Do NOT add new words.",
    "- Do NOT remove words.",
    "- Do NOT rewrite, paraphrase, or reorder anything.",
    "- ONLY wrap spans that already appear verbatim in the input.",
    "- Keep wrapped spans as short as possible.",
    "- Do NOT explain your output.",
    "- If there is nothing to redact, output the input unchanged.",
    "",
    "TEXT:",
    text,
    ].join("\n");

    return this.generateLocal(prompt);
  }

  /**
   * 3) Generic local text generation
   */
  async generateLocal(prompt: string): Promise<string> {
    const r = await fetch(`${env.OLLAMA_URL}/api/generate`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        model: env.OLLAMA_MODEL,
        prompt,
        stream: false,
      }),
    });

    if (!r.ok) throw new Error(`Ollama error ${r.status}`);
    const data: any = await r.json();
    return String(data.response ?? "").trim();
  }
}

export class OpenAiLLM {
  private client = env.OPENAI_API_KEY
    ? new OpenAI({ apiKey: env.OPENAI_API_KEY })
    : null;

  async generateExternal(
    messages: Array<{ role: "system" | "user" | "assistant"; content: string }>
  ): Promise<string> {
    if (!this.client) {
      return "[external-disabled] " + (messages[messages.length - 1]?.content ?? "");
    }

    const resp = await this.client.chat.completions.create({
      model: env.OPENAI_MODEL,
      messages,
      temperature: 0.3,
    });

    return resp.choices[0]?.message?.content?.trim() || "";
  }
}
