import crypto from "node:crypto";

import { Repo } from "./repo";
import { OllamaLLM, OpenAiLLM } from "./llm";

const uuid = () => crypto.randomUUID();

type Entity = { type: string; value: string };

function ageBucket(n: number): string {
  if (!Number.isFinite(n) || n < 0) return "<AGE_UNKNOWN>";
  if (n >= 100) return "<AGE_100_PLUS>";
  const low = Math.floor(n / 10) * 10;
  const high = low + 9;
  return `<AGE_${low}_${high}>`;
}

function stripRedactTags(s: string): string {
  // remove only the wrapper tags, keep inner text
  return s.replace(/<REDACT\s+type="([A-Z]+)">([\s\S]*?)<\/REDACT>/g, "$2");
}

function normalizeForCompare(text: string): string {
  return text.replace(/\s+/g, " ").trim();
}

function applyRedactTags(modelOutput: string): {
  text: string;
  proposed: Array<{ type: string; value: string }>;
} {
  const proposed: Array<{ type: string; value: string }> = [];

  // Allowed tag types only (avoid model inventing types)
  const allowed = new Set(["EMAIL", "PHONE", "NAME", "LOCATION", "DATE", "ID", "AGE"]);

  const out = modelOutput.replace(
    /<REDACT\s+type="([A-Z]+)">([\s\S]*?)<\/REDACT>/g,
    (_full, tRaw, vRaw) => {
      const type = String(tRaw).toUpperCase();
      const value = String(vRaw);

      // If type is not allowed, strip tag but keep content
      if (!allowed.has(type)) return value;

      const trimmed = value.trim();
      if (trimmed.length === 0) return value;

      // Safety: prevent "wrap entire paragraph" behavior
      if (trimmed.length > 80) return value;

      proposed.push({ type, value: trimmed });

      // AGE becomes bucket (deterministic)
      if (type === "AGE") {
        const num = Number(trimmed.match(/\d{1,3}/)?.[0]);
        return ageBucket(num);
      }

      return `<${type}>`;
    }
  );

  return { text: out, proposed };
}


function redactPII(input: string): { anonymized: string; entities: Entity[]; hadPII: boolean } {
  let text = input;
  const entities: Entity[] = [];

  const push = (type: string, value: string) => entities.push({ type, value });

  // Normalization that does NOT rewrite semantics: unify weird whitespace
  // (safe: keeps the same words, helps regex match)
  text = text.replace(/\u00A0/g, " "); // non-breaking space
  text = text.replace(/[ \t]+/g, " "); // collapse horizontal whitespace

  // Helper: replace with capture-based handler (lets us store entities)
  const replaceAll = (regex: RegExp, fn: (...args: any[]) => string) => {
    text = text.replace(regex, (...args) => fn(...args));
  };

  // -------------------------
  // 1) High-confidence tokens
  // -------------------------

  // Email (very high confidence)
  replaceAll(/\b([A-Z0-9._%+-]{1,64}@[A-Z0-9.-]{1,253}\.[A-Z]{2,24})\b/gi, (m, email) => {
    push("EMAIL", email);
    return "<EMAIL>";
  });

  // URLs (optional; sometimes counts as personal data)
  replaceAll(/\bhttps?:\/\/[^\s<>"']+|\bwww\.[^\s<>"']+\b/gi, (m) => {
    push("URL", m);
    return "<URL>";
  });

  // IP addresses (optional)
  replaceAll(/\b(?:(?:25[0-5]|2[0-4]\d|1?\d?\d)\.){3}(?:25[0-5]|2[0-4]\d|1?\d?\d)\b/g, (m) => {
    push("IP", m);
    return "<IP>";
  });

  // Phone numbers (EU/US-ish; anchored to avoid eating random numbers)
  // Matches: +49 170 1234567, (404) 555-1212, 0170-1234567, 0049 170...
  replaceAll(
    /\b(?:\+|00)?\d{1,3}[\s\-()]{0,3}(?:\d[\s\-()]{0,3}){6,14}\d\b/g,
    (m) => {
      // Heuristic: must contain at least 7 digits total
      const digits = m.replace(/\D/g, "");
      if (digits.length < 7) return m;
      push("PHONE", m);
      return "<PHONE>";
    }
  );

  // Credit cards / IBAN (optional but common in “weird requests”)
  // IBAN (DE… etc.)
  replaceAll(/\b([A-Z]{2}\d{2}[A-Z0-9]{11,30})\b/g, (m, iban) => {
    // Avoid false positives on random short tokens
    if (iban.length < 15) return m;
    push("IBAN", iban);
    return "<IBAN>";
  });

  // -------------------------
  // 2) Dates + DOB-ish patterns
  // -------------------------

  // ISO date
  replaceAll(/\b(\d{4}-\d{2}-\d{2})\b/g, (m, d) => {
    push("DATE", d);
    return "<DATE>";
  });

  // Common EU formats: 13.01.2026 / 13/1/26
  replaceAll(/\b(\d{1,2}[./-]\d{1,2}[./-]\d{2,4})\b/g, (m, d) => {
    push("DATE", d);
    return "<DATE>";
  });

  // Explicit DOB phrasing: "born on ...", "date of birth: ..."
  replaceAll(
    /\b(?:born\s+on|date\s+of\s+birth|dob|geb(?:urtsdatum)?|geboren\s+am)\s*[:\-]?\s*(<DATE>|\d{4}-\d{2}-\d{2}|\d{1,2}[./-]\d{1,2}[./-]\d{2,4})\b/gi,
    (m) => {
      push("DOB", m);
      return m.replace(/(<DATE>|\d{4}-\d{2}-\d{2}|\d{1,2}[./-]\d{1,2}[./-]\d{2,4})/i, "<DATE>");
    }
  );

  // -------------------------
  // 3) AGE (bucketed)
  // -------------------------

  // "I am 43", "I'm 43", "im 43", "age: 43", "age is 43"
  replaceAll(
    /\b(?:i\s*am|i'?m|im|my\s*age\s*(?:is)?|age\s*(?:is)?|age)\s*[:\-]?\s*(\d{1,3})\b/gi,
    (m, nStr) => {
      const n = Number(nStr);
      push("AGE", nStr);
      return m.replace(nStr, ageBucket(n));
    }
  );

  // "43 years old" / "43 yo"
  replaceAll(/\b(\d{1,3})\s*(?:years?\s*old|yo|y\/o)\b/gi, (m, nStr) => {
    const n = Number(nStr);
    push("AGE", nStr);
    return m.replace(nStr, ageBucket(n));
  });

  // -------------------------
  // 4) Anchored NAME patterns (high confidence)
  // -------------------------

  // Define “name token”: letters incl. umlauts + accents + hyphen + apostrophe
  // (This covers: Ottenmaier-Klaus, D’Angelo, Jürgen, João)
  const nameToken = `[A-Za-zÀ-ÖØ-öø-ÿßÄÖÜäöüẞ]+(?:[-'’][A-Za-zÀ-ÖØ-öø-ÿßÄÖÜäöüẞ]+)*`;

  // "my name is X", "this is X", "call me X", "i am X" (ONLY if it looks like a name: 1–3 tokens)
  // NOTE: "i am X" is risky; we restrict it to 2–3 tokens OR a single token + nearby "name".
  replaceAll(
    new RegExp(
      String.raw`\b(my\s*name\s*(?:is|:)|this\s*is|call\s*me)\s+(${nameToken}(?:\s+${nameToken}){0,2})\b`,
      "gi"
    ),
    (_m, prefix, nm) => {
      push("NAME", nm);
      return `${prefix} <NAME>`;
    }
  );

  // "i am First Last" / "i'm First Last" / "im First Last" (2–3 tokens ONLY)
  replaceAll(
    new RegExp(
      String.raw`\b(i\s*am|i'?m|im)\s+(${nameToken}\s+${nameToken}(?:\s+${nameToken})?)\b`,
      "gi"
    ),
    (_m, prefix, nm) => {
      push("NAME", nm);
      return `${prefix} <NAME>`;
    }
  );

  // Kinship names: "my father's name is X", "my mom is X"
  replaceAll(
    new RegExp(
      String.raw`\b(my\s*(?:father|dad|mother|mom|brother|sister|husband|wife|partner)(?:'s)?\s*(?:name\s*)?(?:is|:))\s+(${nameToken}(?:\s+${nameToken}){0,2})\b`,
      "gi"
    ),
    (_m, prefix, nm) => {
      push("NAME", nm);
      return `${prefix} <NAME>`;
    }
  );

  // Email-style signatures (common in “long weird requests”):
  // "Regards, Kai", "Best, Helga Ottenmaierklaus", "Danke, Kai"
  replaceAll(
    new RegExp(
      String.raw`(?:\n|^)\s*(regards|best|sincerely|thanks|thank\s+you|cheers|lg|mfg|danke|viele\s+grüße|mit\s+freundlichen\s+grüßen)\s*[,:\-]?\s*(${nameToken}(?:\s+${nameToken}){0,2})\s*(?:\n|$)`,
      "gim"
    ),
    (m, closing, nm) => {
      push("NAME", nm);
      return m.replace(nm, "<NAME>");
    }
  );

  // -------------------------
  // 5) LOCATION (anchored)
  // -------------------------

  // "I live in X", "based in X", "located in X", "I'm in X" — 1–4 tokens
  // (We cap at 4 to reduce accidental over-redaction of normal phrases.)
  replaceAll(
    new RegExp(
      String.raw`\b(i\s*(?:live|am)\s*in|i'?m\s*in|im\s*in|located\s*in|based\s*in)\s+(${nameToken}(?:\s+${nameToken}){0,3})\b`,
      "gi"
    ),
    (_m, prefix, loc) => {
      push("LOCATION", loc);
      return `${prefix} <LOCATION>`;
    }
  );

  // -------------------------
  // 6) IDs (anchored)
  // -------------------------

  // "passport: X", "student id: X", "id number is X"
  replaceAll(
    /\b(passport|student\s*id|matrikel(?:nummer)?|id(?:\s*number)?)\s*[:\-]?\s*([A-Z0-9][A-Z0-9\-]{3,})\b/gi,
    (_m, label, idv) => {
      push("ID", idv);
      return `${label}: <ID>`;
    }
  );

  // Final: had PII?
  const hadPII = entities.length > 0;

  return { anonymized: text, entities, hadPII };
}


// ---------- Services ----------

export class Services {
  private repo = new Repo();
  private ollama = new OllamaLLM();
  private openai = new OpenAiLLM();

  async createSession(userId: string) {
    const sessionId = uuid();
    await this.repo.createSession(sessionId, userId);
    return sessionId;
  }

  async closeSession(sessionId: string) {
    await this.repo.deleteSessionAndData(sessionId);
  }

  // Prefer local unless clearly complex AND not sensitive.
  private complexity(text: string): "simple" | "complex" {
    if (text.length > 240) return "complex";
    if (/compare|plan|strategy|step by step|diagnose|differential|timeline/i.test(text)) return "complex";
    return "simple";
  }

  // Compact conversation context from stored anonymized history
  private buildContext(history: Array<{ role: string; contentAnonymized?: string; contentOriginal?: string }>) {
    const turns = history
      .map((m) => ({
        role: m.role === "assistant" ? "assistant" : "user",
        text: (m.contentAnonymized ?? m.contentOriginal ?? "").trim(),
      }))
      .filter((t) => t.text.length > 0);

    return turns.map((t) => ({ role: t.role as "user" | "assistant", content: t.text }));
  }

  private systemPrompt(): string {
    // Professional "sports health advisor" behavior without false claims.
    return [
      "You are Safe Sport Advisor: a sports-health information assistant (NOT a doctor).",
      "Give practical, cautious, evidence-aligned guidance for sport, training, recovery, and common injuries.",
      "Never claim to diagnose or replace a clinician. For red-flag symptoms, advise urgent/emergency care.",
      "Ask only non-identifying follow-up questions (no names, addresses, emails, exact dates of birth).",
      "If age is relevant, use the provided age bucket (e.g., <AGE_20_29>) without requesting exact age.",
      "Be clear, calm, and structured (what it might be, what to do now, what to avoid, when to seek help).",
      'If the user message contains placeholders like <EMAIL>, <LOCATION>, <NAME>, treat them as already-redacted and continue helping (do not refuse solely because placeholders are present).',
    ].join("\n");
  }

  async handleMessage(input: { sessionId: string; userId: string; message: string }) {
    const { sessionId, userId, message } = input;

    // refresh TTL
    await this.repo.touchSession(sessionId, userId);

    // history (already minimized)
    const history = await this.repo.getRecentMessages(sessionId, 12);

    // 1) Deterministic PII redaction FIRST
    let redaction = redactPII(message);

    // 1.5) Second-pass: local LLM marks extra sensitive spans with <REDACT ...> tags.
    // We then apply them deterministically (we do NOT trust free-form rewriting).
    try {
      const tagged = await this.ollama.proposeRedactions(redaction.anonymized);

      // Guardrail 1: ignore if model produced too many tags
      const tagCount = (tagged.match(/<REDACT\s+type="/g) || []).length;
      if (tagCount > 20) throw new Error("too_many_tags");

      // Guardrail 2 (CRITICAL): only accept if removing tags yields the same text
      // (ignoring whitespace-only differences).
      const stripped = stripRedactTags(tagged).trim();
      const original = redaction.anonymized.trim();

      // Tolerate whitespace-only differences (local models often adjust spacing/newlines).
      // Still rejects any actual rewriting / paraphrasing.
      if (normalizeForCompare(stripped) !== normalizeForCompare(original)) {
        // Model rewrote/refused/added commentary → ignore entirely
        throw new Error("tagger_rewrote_text");
      }

      const applied = applyRedactTags(tagged);

      redaction = {
        anonymized: applied.text,
        entities: [...redaction.entities, ...applied.proposed.map((p) => ({ type: p.type, value: p.value }))],
        hadPII: redaction.hadPII || applied.proposed.length > 0,
      };
    } catch {
      // If tagging fails, deterministic redaction still protects us.
    }

    // 2) Optional extra sensitivity signal from local model (kept local)
    // Even if the model fails to extract entities, we already redacted deterministic PII above.
    const detection = await this.ollama.detectSensitive(redaction.anonymized);
    const isSensitive = Boolean(redaction.hadPII || detection.isSensitive);

    // Decide route
    const isComplex = this.complexity(redaction.anonymized) === "complex";
    const route: "local" | "external" = isSensitive ? "local" : isComplex ? "external" : "local";

    const routeReason = isSensitive ? "sensitive_detected" : route === "local" ? "simple_or_prefer_local" : "complex_non_sensitive";

    // Persist USER turn — store anonymized only (IMPORTANT: pass no contentOriginal)
    await this.repo.appendMessage({
      sessionId,
      userId,
      role: "user",
      contentAnonymized: redaction.anonymized,
      // still not storing entities in DB (minimization).
      route,
      routeReason: "stored_anonymized_only",
    });

    const contextMsgs = this.buildContext(history);

    let response = "";

    if (route === "local") {
      const prompt = [
        `SYSTEM: ${this.systemPrompt()}`,
        "",
        ...contextMsgs.map((m) => `${m.role.toUpperCase()}: ${m.content}`),
        `USER: ${redaction.anonymized}`,
        "ASSISTANT:",
      ].join("\n");

      response = await this.ollama.generateLocal(prompt);
    } else {
      response = await this.openai.generateExternal([
        { role: "system", content: this.systemPrompt() },
        ...contextMsgs,
        { role: "user", content: redaction.anonymized },
      ]);
    }

    // Persist ASSISTANT turn — also store anonymized only (no contentOriginal)
    await this.repo.appendMessage({
      sessionId,
      userId,
      role: "assistant",
      contentAnonymized: response,
      route,
      routeReason,
    });

    return {
      response,
      usedModel: route,
      // return redaction entities to the frontend (for demo / transparency)
      redactions: (() => {
        const out = redaction.entities.map((e) => {
          if (e.type === "AGE") {
            const matches = redaction.anonymized.match(/<AGE_\d+_\d+>|<AGE_100_PLUS>|<AGE_UNKNOWN>/g);
            const bucket = matches?.[matches.length - 1];
            return { type: "AGE", placeholder: bucket ?? "<AGE>" };
          }
          return { type: e.type, placeholder: `<${e.type}>` };
        });

        // Dedupe by type+placeholder for nicer UI
        const seen = new Set<string>();
        return out.filter((r) => {
          const key = `${r.type}|${r.placeholder}`;
          if (seen.has(key)) return false;
          seen.add(key);
          return true;
        });
      })(),
    };
  }
}
