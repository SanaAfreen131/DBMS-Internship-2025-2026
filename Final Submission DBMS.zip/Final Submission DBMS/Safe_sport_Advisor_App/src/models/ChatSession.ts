import mongoose, { Schema, model } from "mongoose";

const MessageSchema = new Schema(
  {
    from: { type: String, required: true }, // "user" | "assistant"
    text: { type: String, required: true },
    textAnonymized: { type: String, default: "" },
    entities: { type: Array, default: [] },
    route: { type: String, default: "local" }, // "local" | "external"
    routeReason: { type: String, default: "" },
    timestamp: { type: Date, default: Date.now },
  },
  { _id: false }
);

const ChatSessionSchema = new Schema({
  sessionId: { type: String, required: true, unique: true, index: true },
  userId: { type: String, required: true },

  messages: { type: [MessageSchema], default: [] },

  createdAt: { type: Date, default: Date.now },

  // TTL field (indexed via schema-level TTL index below)
  expiresAt: { type: Date, required: true },
});

// TTL index: delete automatically once expiresAt is reached
ChatSessionSchema.index({ expiresAt: 1 }, { expireAfterSeconds: 0 });

export const ChatSession =
  (mongoose.models.ChatSession as mongoose.Model<any>) ||
  model("ChatSession", ChatSessionSchema);
